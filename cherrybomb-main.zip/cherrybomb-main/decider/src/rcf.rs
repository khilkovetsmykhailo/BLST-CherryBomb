use super::*;

pub fn decide_rcf(digest:Digest,session:Session)->bool{
    false
}
pub fn load_rcf(req_res:Vec<ReqRes>){
    
}
